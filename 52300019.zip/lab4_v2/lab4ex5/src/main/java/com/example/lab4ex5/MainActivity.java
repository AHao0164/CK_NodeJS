package com.example.lab4ex5;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private UserAdapter adapter;
    private TextView tvTotalUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<User> userList = new ArrayList<>();

        adapter = new UserAdapter(userList);
        recyclerView.setAdapter(adapter);

        tvTotalUsers = findViewById(R.id.tvTotalUsers);
        updateTotalUsers();

        Button btnAddUsers = findViewById(R.id.btnAddUsers);
        btnAddUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adapter.addFiveUsers();
                updateTotalUsers();
                Toast.makeText(MainActivity.this, "Added 5 users", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnRemoveUsers = findViewById(R.id.btnRemoveUsers);
        btnRemoveUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adapter.getUserCount() == 0) {
                    Toast.makeText(MainActivity.this, "List of users is empty", Toast.LENGTH_SHORT).show();
                } else {
                    adapter.removeLastFiveUsers();
                    updateTotalUsers();
                    if (adapter.getUserCount() == 0) {
                        Toast.makeText(MainActivity.this, "List of users is empty", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Removed users", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void updateTotalUsers() {
        tvTotalUsers.setText("Total users: " + adapter.getUserCount());
    }
}