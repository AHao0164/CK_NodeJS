package com.example.lab4ex5;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
    private List<User> userList;

    public UserAdapter(List<User> userList) {
        this.userList = userList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsername;
        TextView tvEmail;

        public ViewHolder(View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUsername);
            tvEmail = itemView.findViewById(R.id.tvEmail);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        User user = userList.get(position);
        holder.tvUsername.setText(user.getUsername());
        holder.tvEmail.setText(user.getEmail());
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public void addFiveUsers() {
        int currentSize = userList.size();
        for (int i = 1; i <= 5; i++) {
            int userNumber = currentSize + i;
            userList.add(new User("User " + userNumber, "user" + userNumber + "@tdtu.edu.vn"));
        }
        notifyDataSetChanged();
    }

    public boolean removeLastFiveUsers() {
        int size = userList.size();
        if (size == 0) {
            return false;
        }
        
        int removeCount = Math.min(5, size);
        for (int i = 0; i < removeCount; i++) {
            userList.remove(userList.size() - 1);
        }
        notifyDataSetChanged();
        return true;
    }

    public int getUserCount() {
        return userList.size();
    }
}
