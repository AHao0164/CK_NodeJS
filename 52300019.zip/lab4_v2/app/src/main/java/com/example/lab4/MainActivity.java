package com.example.lab4;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        RecyclerView recycleView = findViewById(R.id.recycleView);
        recycleView.setLayoutManager(new LinearLayoutManager(this));
        MyAdapter adapter = getMyAdapter();
        recycleView.setAdapter(adapter);
    }

    @NonNull
    private MyAdapter getMyAdapter() {
        List<String> items = new ArrayList<>();
        Random random = new Random();
        int count = random.nextInt(20) + 1;
        for (int i = 0; i < count; i++) {
            items.add("Item " + (i + 1));
        }
        MyAdapter adapter = new MyAdapter(items);
        adapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                String itemValue = items.get(position);
                Toast.makeText(MainActivity.this, itemValue, Toast.LENGTH_SHORT).show();
            }
        });
        return adapter;
    }

}

