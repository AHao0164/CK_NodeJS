package com.example.lab4ex2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) RecyclerView recycleView = findViewById(R.id.recycleView);
        recycleView.setLayoutManager(new LinearLayoutManager(this));
        List<String> items = new ArrayList<>();
        Random random = new Random();
        int count = random.nextInt(20) + 1;
        for (int i = 0; i < count; i++) {
            items.add("Item " + (i + 1));
        }
        MyAdapter adapter = new MyAdapter(items);
        recycleView.setAdapter(adapter);

        adapter.setOnItemClickListener(new MyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                String itemValue = items.get(position);
                Toast.makeText(MainActivity.this, itemValue, Toast.LENGTH_SHORT).show();
            }
        });
        
        adapter.setOnRemoveClickListener(new MyAdapter.OnRemoveClickListener() {
            @Override
            public void onRemoveClick(int position) {
                items.remove(position);
                adapter.notifyItemRemoved(position);
                adapter.notifyItemRangeChanged(position, items.size());
                Toast.makeText(MainActivity.this, "Đã xóa item", Toast.LENGTH_SHORT).show();
            }
        });
    }

}