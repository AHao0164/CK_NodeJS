package com.example.lab4ex4;

public class MyItem {
    private String name;
    private boolean isConnected;

    public MyItem(String name) {
        this.name = name;
        this.isConnected = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isConnected() {
        return isConnected;
    }

    public void setConnected(boolean connected) {
        isConnected = connected;
    }

    public void toggleConnection() {
        this.isConnected = !this.isConnected;
    }
}
