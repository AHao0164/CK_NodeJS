package com.example.lab4ex4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private List<MyItem> pcList;

    public MyAdapter(List<MyItem> pcList) {
        this.pcList = pcList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivWifiStatus;
        TextView tvPCName;

        public ViewHolder(View itemView) {
            super(itemView);
            ivWifiStatus = itemView.findViewById(R.id.ivWifiStatus);
            tvPCName = itemView.findViewById(R.id.tvPCName);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        MyItem item = pcList.get(position);
                        item.toggleConnection();
                        
                        if (item.isConnected()) {
                            ivWifiStatus.setImageResource(R.drawable.wifi_connected);
                        } else {
                            ivWifiStatus.setImageResource(R.drawable.wifi_disconected);
                        }
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        MyItem item = pcList.get(position);
        holder.tvPCName.setText(item.getName());
        
        if (item.isConnected()) {
            holder.ivWifiStatus.setImageResource(R.drawable.wifi_connected);
        } else {
            holder.ivWifiStatus.setImageResource(R.drawable.wifi_disconected);
        }
    }

    @Override
    public int getItemCount() {
        return pcList.size();
    }
}
