package com.example.lab4ex3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private MyAdapter adapter;
    private List<PhoneItem> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        RecyclerView recycleView = findViewById(R.id.recycleView);
        recycleView.setLayoutManager(new LinearLayoutManager(this));

        items = new ArrayList<>();
        items.add(new PhoneItem("Apple"));
        items.add(new PhoneItem("Samsung"));
        items.add(new PhoneItem("Nokia"));
        items.add(new PhoneItem("Oppo"));

        adapter = new MyAdapter(items);
        recycleView.setAdapter(adapter);

        Button btnRemoveAll = findViewById(R.id.button);
        btnRemoveAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!items.isEmpty()) {
                    adapter.removeAll();
                    Toast.makeText(MainActivity.this, "Đã xóa tất cả", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Danh sách trống", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button btnRemoveSelected = findViewById(R.id.button2);
        btnRemoveSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedCount = 0;
                for (PhoneItem item : items) {
                    if (item.isSelected()) {
                        selectedCount++;
                    }
                }

                if (selectedCount > 0) {
                    adapter.removeSelected();
                    Toast.makeText(MainActivity.this, "Đã xóa " + selectedCount + " mục", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Chưa chọn mục nào", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}