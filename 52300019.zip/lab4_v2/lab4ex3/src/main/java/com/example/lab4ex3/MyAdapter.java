package com.example.lab4ex3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private List<PhoneItem> dataList;

    public MyAdapter(List<PhoneItem> dataList) {
        this.dataList = dataList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItem;
        CheckBox checkBox;

        public ViewHolder(View itemView) {
            super(itemView);
            tvItem = itemView.findViewById(R.id.tvItem);
            checkBox = itemView.findViewById(R.id.checkBox);

            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        PhoneItem item = dataList.get(position);
                        item.setSelected(checkBox.isChecked());
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        PhoneItem item = dataList.get(position);
        holder.tvItem.setText(item.getName());
        holder.checkBox.setChecked(item.isSelected());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void removeAll() {
        dataList.clear();
        notifyDataSetChanged();
    }

    public void removeSelected() {
        for (int i = dataList.size() - 1; i >= 0; i--) {
            if (dataList.get(i).isSelected()) {
                dataList.remove(i);
            }
        }
        notifyDataSetChanged();
    }
}
